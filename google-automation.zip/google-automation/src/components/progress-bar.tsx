interface ProgressBarProps {
    index: number
}
export const ProgressBar: React.FC<ProgressBarProps> = ({ index }) => {
    console.log(Array([1, 2, 3, 4, 5]))
    return (
        <>

            <div className="flex relative">
                {/* {
                    [1, 2, 3, 4].map((e) => {
                        return 
                    })
                } */}
                <div className="flex justify-evenly w-full z-10">
                    <div className="h-1  w-2 bg-white"></div>
                    <div className="h-1  w-2 bg-white"></div>
                    <div className="h-1  w-2 bg-white"></div>
                </div>
                <div className="h-1 flex-1 bg-gray-200 rounded absolute w-full"></div>
                <div className={`h-1 flex-1 bg-black rounded absolute left-0 top-0 transition-all`} style={{ width: `${(index + 1) * 25}%` }}></div>
            </div>

        </>
    )
}
