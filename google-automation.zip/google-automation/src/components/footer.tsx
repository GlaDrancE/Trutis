
interface FooterProps {
    next?: () => void | undefined
    prev?: () => void | undefined
    btnType?: "button" | "submit"
    disable?: true | false
    nxt_text?: string
}
export const Footer: React.FC<FooterProps> = ({ next, prev, btnType = 'button', disable = false, nxt_text }) => {
    return (
        <>
            <div className="px-4 pb-8 space-y-4">
                <p className="text-center text-xs text-gray-600">
                    By clicking continue, you agree to our{' '}
                    <button
                        className="text-black underline bg-transparent"
                    >
                        Terms of Service
                    </button>{' '}
                    and{' '}
                    <button
                        className="text-black underline bg-transparent"
                    >
                        Privacy Policy
                    </button>
                </p>

                <button
                    className={`w-full ${disable ? 'bg-gray-300' : 'bg-black'} text-white py-2 rounded-lg font-medium`}
                    onClick={next}
                    type={btnType}

                    disabled={disable}
                >
                    {nxt_text ? nxt_text : "Continue"}
                </button>

                <button
                    className="w-full bg-gray-100 text-black py-2 rounded-lg font-medium"
                    onClick={prev}
                    type="button"
                >
                    Back
                </button>
            </div>
        </>
    )
}
