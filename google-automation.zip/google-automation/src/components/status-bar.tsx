export const StatusBar = () => {
  return (
    <>
      {/* Status Bar */}
      <div className="px-4 py-3 flex items-center">
        <span className="text-sm text-black">9:41</span>
        <div className="flex-grow"></div>
        <div className="flex items-center space-x-1">
          <div className="w-4 h-4">
            <svg viewBox="0 0 24 24" className="w-full h-full">
              <path
                fill="currentColor"
                d="M12 21.5c5.523 0 10-4.477 10-10S17.523 1.5 12 1.5 2 5.977 2 11.5s4.477 10 10 10z"
              />
            </svg>
          </div>
        </div>
      </div>
    </>
  );
};
