import React from 'react';
import { ProgressBar } from './components/progress-bar';
interface WelcomePageProps {
    children: React.ReactNode
    index: number
}

const WelcomePage: React.FC<WelcomePageProps> = ({ children, index }) => {
    return (
        <div className="max-h-screen h-screen bg-white flex flex-col max-w-[425px] pt-4 m-auto ">
            {/* <StatusBar /> */}
            <ProgressBar index={index} />


            <div className={`text-2xl font-bold text-center mb-8 pt-8 transition-all duration-500   ${index != 0 ? 'translate-y-0' : 'translate-y-[11rem]'}`}>Logo</div>

            <main className='flex justify-center w-full flex-grow'>
                {children}
            </main>
        </div>
    );
};

export default WelcomePage;