import { useState } from "react"
import WelcomePage from "./google-review"
import { GreetingsPage } from "./pages/GreetingsPage"
import { LandingPage } from "./pages/LandingPage"
import { LeadCollection } from "./pages/LeadCollection"
import { ReviewPage } from "./pages/ReviewPage"


import { useTransition, animated } from '@react-spring/web';


const steps = [
  { id: 1, component: LandingPage },
  { id: 2, component: LeadCollection },
  { id: 3, component: ReviewPage },
  { id: 4, component: GreetingsPage },
  // Add more steps here
];
function App() {

  const [index, setIndex] = useState(0);

  const nextStep = () => {
    if (index === steps.length - 1) {
      return
    }

    setIndex((prev) => (prev + 1) % steps.length);
  };
  const prevStep = () => {
    if (index === 0) {
      return
    }
    setIndex((prev) => (prev - 1) % steps.length);
  };

  const transitions = useTransition(index, {
    key: index,
    from: { opacity: 0, translateX: '1rem' },
    enter: { opacity: 1, translateX: '0' },
    leave: { opacity: 0, translateX: '-1rem' },
  });

  return (
    <>
      <main className="flex justify-center overflow-hidden max-h-screen">
        <div style={{ position: 'relative', width: '100%', height: '100%', overflow: 'hidden', maxHeight: '100vh' }}>
          <div className=" max-h-screen">

            {transitions((style, i) => {
              const StepComponent = steps[i].component;
              return (
                <WelcomePage index={index}>
                  <animated.div style={{ ...style, position: 'relative', width: '100%', flexGrow: '1', display: 'flex', flexDirection: 'column' }}>
                    <StepComponent next={nextStep} prev={prevStep} />
                  </animated.div>
                </WelcomePage>
              );
            })}
          </div>
        </div>
      </main>
    </>
  )
}

export default App
