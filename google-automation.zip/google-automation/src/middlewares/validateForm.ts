// types.ts
export interface ValidationResult {
  isValid: boolean;
  error: string;
}

export interface FormData {
  name: string;
  email: string;
  phone: string;
}

export interface FormErrors {
  [key: string]: string;
}

export type FieldName = keyof FormData;

// validation.ts
export class ValidationUtils {
  private static readonly NAME_REGEX = /^[a-zA-Z\s]{2,30}$/;
  private static readonly EMAIL_REGEX =
    /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  private static readonly PHONE_REGEX =
    /^(\+\d{1,3}[-.]?)?(?!0)\(?([1-9][0-9]{2})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;

  public static validateField(
    fieldName: FieldName,
    value: string
  ): ValidationResult {
    if (!value.trim()) {
      return {
        isValid: false,
        error: "",
      };
    }

    switch (fieldName) {
      case "name":
        return this.validateName(value);
      case "email":
        return this.validateEmail(value);
      case "phone":
        return this.validatePhone(value);
      default:
        return { isValid: true, error: "" };
    }
  }

  private static validateName(name: string): ValidationResult {
    if (name.length < 2) {
      return {
        isValid: false,
        error: "Name must be at least 2 characters long",
      };
    }

    if (name.length > 30) {
      return {
        isValid: false,
        error: "Name must not exceed 30 characters",
      };
    }

    if (!this.NAME_REGEX.test(name)) {
      return {
        isValid: false,
        error: "Name can only contain letters and spaces",
      };
    }

    return { isValid: true, error: "" };
  }

  private static validateEmail(email: string): ValidationResult {
    if (!this.EMAIL_REGEX.test(email)) {
      return {
        isValid: false,
        error: "Please enter a valid email address",
      };
    }

    return { isValid: true, error: "" };
  }

  private static validatePhone(phone: string): ValidationResult {
    if (!this.PHONE_REGEX.test(phone.replace(/^0+/, ""))) {
      return {
        isValid: false,
        error: "Please enter a valid phone number",
      };
    }

    return { isValid: true, error: "" };
  }

  public static validateForm(formData: FormData): {
    isFormValid: boolean;
    errors: FormErrors;
  } {
    const errors: FormErrors = {};
    let isFormValid = true;

    (Object.keys(formData) as FieldName[]).forEach((field) => {
      const validation = this.validateField(field, formData[field]);
      if (!validation.isValid) {
        errors[field] = validation.error;
        isFormValid = false;
      }
    });

    return { isFormValid, errors };
  }
}
