import React, { FormEvent, useState } from 'react'
import { Star } from 'lucide-react'
import { Footer } from '../components/footer';
import axios from 'axios';
import RatingBelowFeedbackForm from './ratingbelow';
import RatingAboveFeedbackForm from './ratingabove';

interface ReviewPageProps {
    next: () => void;
    prev: () => void;
}
export const ReviewPage: React.FC<ReviewPageProps> = ({ next, prev }) => {
    const [rating, setRating] = useState<number>(0);
    const [showFeedback, setShowFeedback] = useState<true | false>(false)
    const [showReview, setShowReview] = useState<true | false>(false)
    const [hoveredRating, setHoveredRating] = useState<number>(0);
    const [isValid, setIsValid] = useState<boolean>(false)

    // const handleContinue = () => {
    //     onContinue?.(rating);
    // };
    const handleSubmit = async (e: FormEvent) => {
        e.preventDefault();
        const res = await axios.post('www.webhooklink.com', { rating: rating })
        console.log(res)
    }
    const handleNext = () => {
        if (rating < 3) {
            setShowFeedback(true)
        } else {
            setShowReview(true)
        }
    }
    const handleSetRating = (star: number): void => {
        setIsValid(true);
        setRating(star)
    }
    return (
        <>

            <div className={`flex-grow flex flex-col items-center px-4 h-full transition-all  ${(showFeedback || showReview) && 'absolute opacity-0 -z-10'}`}>

                <h1 className="text-2xl font-semibold mb-2">Give us a Review</h1>
                <p className="text-center text-gray-600 mb-8">Your valuable feedback will help us</p>

                <form className='' onSubmit={handleSubmit}>
                    <div className="flex space-x-4 mb-16 justify-center">
                        {[1, 2, 3, 4, 5].map((star) => (
                            <button
                                key={star}
                                onClick={() => handleSetRating(star)}
                                onMouseEnter={() => setHoveredRating(star)}
                                onMouseLeave={() => setHoveredRating(0)}
                                className="focus:outline-none"
                                type='button'
                            >
                                <Star
                                    size={30}
                                    className={`transition-colors ${star <= (hoveredRating || rating)
                                        ? 'fill-indigo-400 stroke-indigo-400'
                                        : 'stroke-indigo-400'
                                        }`}
                                />
                            </button>
                        ))}
                    </div>
                    <Footer next={handleNext} prev={prev} btnType='submit' disable={!isValid} />
                </form>


            </div >
            <div className={`flex-grow  transition-all duration-500 flex flex-col items-center px-4 h-full ${!showFeedback ? 'opacity-0 absolute -z-10' : 'relative opacity-1 z-0'}`}>

                <RatingBelowFeedbackForm next={next} prev={prev} />
            </div>
            <div className='flex-grow flex flex-col items-center px-4 h-full' style={{ opacity: showReview ? 1 : 0 }}>

                <RatingAboveFeedbackForm next={next} prev={prev} showReview={showReview} />
            </div>

        </>
    )
}
