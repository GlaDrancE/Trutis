import React from 'react'
import { Footer } from '../components/footer';

interface GreetingsPage {
    next: () => void;
    prev: () => void;
}
export const GreetingsPage: React.FC<GreetingsPage> = ({ next, prev }) => {
    return (
        <>
            <div className="flex-grow flex flex-col items-center px-4">

                <h1 className="text-2xl font-semibold mb-2 text-center">Thank you for your valuable Feedback</h1>
                <p className="text-gray-600 mb-8">Check your email for the</p>

                {/* Gift Box and Confetti */}
                <div className="relative w-32 h-32 mb-8">
                    {/* Confetti */}
                    <svg className="absolute w-64 h-64 inset-0 -left-1/2 -top-1/2" viewBox="0 0 100 100">
                        {[...Array(50)].map((_, i) => (
                            <circle
                                key={i}
                                cx={Math.random() * 100}
                                cy={Math.random() * 100}
                                r={Math.random() * 1}
                                fill={`hsl(${Math.random() * 360}, 80%, 60%)`}
                                className="animate-[confetti_2s_ease-out_infinite]"
                                style={{
                                    transformOrigin: 'center',
                                    animation: `confetti ${1 + Math.random() * 2}s ease-out infinite`,
                                    animationDelay: `${Math.random() * 2}s`
                                }}
                            />
                        ))}
                    </svg>

                    {/* Gift Box */}
                    <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-32 h-32 relative">
                            {/* Box Base */}
                            <div className="absolute bottom-0 w-full h-3/4 bg-red-500 rounded"></div>
                            {/* Box Lid */}
                            <div className="absolute top-0 w-full h-1/4 bg-red-400 rounded-t transform -rotate-12 origin-bottom"></div>
                            {/* Box Ribbon */}
                            <div className="absolute inset-0 flex items-center justify-center">
                                <div className="text-4xl font-bold">10%</div>
                            </div>
                        </div>
                    </div>
                </div>

                <p className="text-lg font-medium text-center mb-4">Coupon Code</p>
            </div>

            <Footer next={next} prev={prev} nxt_text='Done' />
        </>
    )
}
