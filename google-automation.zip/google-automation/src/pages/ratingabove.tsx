// types.ts
export interface FeedbackFormData {
    feedback: string;
}
interface FeedbackFormProps {

    next: () => void;
    prev: () => void;
    showReview?: boolean
}

// FeedbackForm.tsx
import React, { FormEvent } from 'react';
import googleIcon from '../assets/google.svg'
// import { FeedbackFormData } from './types';

const RatingAboveFeedbackForm: React.FC<FeedbackFormProps> = ({ next, showReview }) => {
    // const [formData, setFormData] = useState<FeedbackFormData>({
    //     feedback: ''
    // });
    // const [error, setError] = useState<string>('');

    const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();

        // Handle form submission
    };
    return (
        <form onSubmit={handleSubmit} className="space-y-6 w-full">
            <div className="space-y-2">
                <h2 className="text-xl font-semibold text-center">
                    Give us a Google Review                </h2>
                <p className="text-gray-500 text-center text-sm">
                    Your valuable feedback will help us                </p>
            </div>
            <button
                className={`w-full bg-gray-100 text-black py-2 rounded-lg font-medium flex items-center justify-center transition-all duration-500 ${showReview ? 'translate-y-0 opacity-1' : 'translate-y-[20rem] opacity-0'}`}
                onClick={next}
                type="button"
            >

                <img src={googleIcon} alt="" className='mr-2' />
                Google Review
            </button>
        </form>
    );
};

export default RatingAboveFeedbackForm;