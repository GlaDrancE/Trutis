import { useEffect, useState } from "react";
import { Footer } from "../components/footer";
import axios from "axios";
import { ValidationUtils } from "../middlewares/validateForm";

interface SignUpFormProps {
    onContinue?: (data: FormData) => void;
    onBack?: () => void;
    onTermsClick?: () => void;
    onPrivacyClick?: () => void;
    next: () => void;
    prev: () => void;
}

interface FormData {
    name: string;
    phone: string;
    email: string;
}
interface Errors {
    [nameError: string]: string;
}

export const LeadCollection: React.FC<SignUpFormProps> = ({
    next,
    prev
}) => {
    const [formData, setFormData] = useState<FormData>({
        name: '',
        phone: '',
        email: '',
    });
    const [error, setErrors] = useState<Errors>({
        nameError: '',
        emailError: '',
        phoneError: '',
    })

    const [btnDisable, setBtnDisable] = useState<true | false>(true);
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const { isFormValid, errors } = ValidationUtils.validateForm(formData)

    useEffect(() => {
        if (isFormValid) {
            setBtnDisable(false)
        }
        else {
            setBtnDisable(true)
        }
        setErrors(((prev => ({ ...prev, nameError: errors.name ? errors.name : '' }))))
        setErrors((prev => ({ ...prev, emailError: errors.email ? errors.email : '' })))
        setErrors(prev => ({ ...prev, phoneError: errors.phone ? errors.phone : '' }))
    }, [isFormValid, errors])
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!isFormValid) return
        const res = await axios.post('www.webhook.com', { name: formData.name, phone: formData.phone, email: formData.email })
        // const res = await axios.post('https://hook.eu2.make.com/gompuiwq9019i2d59yqtki5c3igrgn62', { name: formData.name, phone: formData.phone, email: formData.email })
        console.log(res)
    };

    return (
        <>
            <div className="flex-grow flex flex-col px-4">
                <h1 className="text-2xl font-semibold text-center mb-2">Fill in the Details</h1>
                <p className="text-center text-gray-600 mb-8">Get a 10% discount right now</p>

                <form onSubmit={handleSubmit} className="space-y-4">
                    <input
                        type="text"
                        name="name"
                        placeholder="Name"
                        value={formData.name}
                        onChange={handleChange}
                        className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-black"
                    />

                    {error.nameError && <p className="text-red-500 text-sm !m-0 ">{error.nameError}</p>}
                    <input
                        type="tel"
                        name="phone"
                        placeholder="Phone"
                        value={formData.phone.replace(/^0+/, "")}
                        onChange={handleChange}
                        className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-black"
                    />

                    {error.phoneError && <p className="text-red-500 text-sm !m-0 ">{error.phoneError}</p>}
                    <input
                        type="email"
                        name="email"
                        placeholder="Email"
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-black"
                    />
                    {error.emailError && <p className="text-red-500 text-sm !m-0 ">{error.emailError}</p>}
                    <Footer next={next} prev={prev} btnType="submit" disable={btnDisable} nxt_text="Submit" />
                </form>
            </div>

        </>
    )
}
