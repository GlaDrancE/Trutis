import React from 'react'
import { Footer } from '../components/footer'

interface LandingPageProps {
    next: () => void;
    prev: () => void;
}
export const LandingPage: React.FC<LandingPageProps> = ({ next, prev }) => {
    return (
        <>
            <div className="flex-grow flex flex-col items-center justify-center px-4">
                {/* <div className="text-2xl font-bold mb-4">Logo</div> */}
            </div>


            <Footer next={next} prev={prev} />
        </>
    )
}
