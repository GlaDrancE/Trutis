// types.ts
export interface FeedbackFormData {
    feedback: string;
}
interface FeedbackFormProps {

    next: () => void;
    prev: () => void;
}

// FeedbackForm.tsx
import React, { useState, FormEvent } from 'react';
import { Footer } from '../components/footer';
// import { FeedbackFormData } from './types';

const RatingBelowFeedbackForm: React.FC<FeedbackFormProps> = ({ next, prev }) => {
    const [formData, setFormData] = useState<FeedbackFormData>({
        feedback: ''
    });
    const [error, setError] = useState<string>('');

    const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();

        if (!formData.feedback.trim()) {
            setError('Please provide your feedback');
            return;
        }

        // Handle form submission
        console.log('Feedback submitted:', formData);
        // Reset form after submission
        setFormData({ feedback: '' });
        setError('');
    };
    return (
        <form onSubmit={handleSubmit} className="space-y-6 w-full">
            <div className="space-y-2">
                <h2 className="text-xl font-semibold text-center">
                    Tell us about your Experience
                </h2>
                <p className="text-gray-500 text-center text-sm">
                    Your valuable feedback will help us
                </p>
            </div>

            {/* Feedback Textarea */}
            <div>
                <textarea
                    value={formData.feedback}
                    onChange={(e) => setFormData({ feedback: e.target.value })}
                    placeholder="Write us your concern"
                    className="w-full h-40 p-4 border border-gray-200 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs"
                />
                {error && <p className="text-red-500 text-sm">{error}</p>}
            </div>

            <Footer next={formData.feedback ? next : undefined} prev={prev} btnType='submit' />
        </form>
    );
};

export default RatingBelowFeedbackForm;